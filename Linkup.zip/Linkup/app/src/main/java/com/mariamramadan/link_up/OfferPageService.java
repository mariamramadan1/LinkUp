package com.mariamramadan.link_up;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class OfferPageService extends AppCompatActivity
{
    String ClientName, ClientPhone, TimeStamp, ServiceName, ServicePhone, Status;
    Button AcceptOffer, DeclineOffer;
    TextView NameText;
    FirebaseUser CurrentUser;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    EditText NameText2, PhoneText ,StatusText;

    public void ModifyOfferStatus(int status, String ts)
    {
//        db.collection("Offers").orderBy("Phone", Query.Direction.ASCENDING).addSnapshotListener
//                (new EventListener<QuerySnapshot>()
//                {
//                    @Override
//                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error)
//                    {
//                        CurrentUser= FirebaseAuth.getInstance().getCurrentUser();
//                        ClientPhone= CurrentUser.getPhoneNumber();
//                        if(error != null)
//                        {
//                            Log.e(TAG, "Firebase Error");
//                            return;
//                        }
//                        for (DocumentChange dc: value.getDocumentChanges())
//                        {
//                            if (ts.equals((String) dc.getDocument().get("TimeStamp")))
//                            {
//                                Map<String, Object> offerUpdate = new HashMap<>();
//                                offerUpdate.put("ClientName", CurrentName);
//                                offerUpdate.put("ClientPhone", ClientPhone);
//                                offerUpdate.put("ServiceName", FNservice+ " " + LNService);
//                                offerUpdate.put("ServicePhone", PhoneService);
//                                offerUpdate.put("Status", status);
//
//                            }
//
//                        }
//
//
//
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
//                        {
//                            user.put("TimeStamp", ts);
//                        }
//
//                        db.collection("Offers")
//                                .add(user)
//                                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                                    @Override
//                                    public void onSuccess(DocumentReference documentReference)
//                                    {
//                                        Toast.makeText(ProfileServiceClientView.this, "Request sent to "+
//                                                Fname + " "+ Lname, Toast.LENGTH_LONG).show();
//                                    }
//                                })
//                                .addOnFailureListener(new OnFailureListener()
//                                {
//                                    @Override
//                                    public void onFailure(@NonNull Exception e)
//                                    {
//                                        Toast.makeText(ProfileServiceClientView.this,
//                                                "Failed, please try again", Toast.LENGTH_LONG).show();
//                                    }
//                                });
//                    }
//                });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offer_page_service);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.linkup_background)));

        NavigationBarView BottomBar= (NavigationBarView) findViewById(R.id.bottomNavigationView);

        ClientName= getIntent().getStringExtra("ClientName");
        ClientPhone= getIntent().getStringExtra("ClientPhone");
        TimeStamp= getIntent().getStringExtra("TimeStamp");
        Status= getIntent().getStringExtra("Status");
        ServiceName= getIntent().getStringExtra("ServiceName");
        ServicePhone=getIntent().getStringExtra("ServicePhone");

        NameText= (TextView) findViewById(R.id.name);
        NameText2= (EditText) findViewById(R.id.ClientName);
        PhoneText= (EditText) findViewById(R.id.ClientPhone);
        StatusText= (EditText) findViewById(R.id.Status);

        NameText.setText(ClientName);
        NameText2.setText(ClientName);
        PhoneText.setText(ClientPhone);
        if (Status.equals("1"))
        {
            StatusText.setText("Accepted");
        }
        else if (Status.equals("2"))
        {
            StatusText.setText("Rejected");
        }
        else
        {
            StatusText.setText("Pending");
        }

        NameText2.setEnabled(false);
        PhoneText.setEnabled(false);
        StatusText.setEnabled(false);

        BottomBar.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                switch(item.getItemId())
                {
                    case R.id.Home:
                    {
                        Intent toHome= new Intent(getApplicationContext(), HomeServiceProv.class);
                        startActivity(toHome);
                        overridePendingTransition(0,0);
                        return true;
                    }
                    case R.id.Bookings:
                    {
                        Intent toBookings= new Intent(getApplicationContext(), BookingService.class);
                        startActivity(toBookings);
                        overridePendingTransition(0,0);
                        return true;
                    }
                    case R.id.profile:
                    {
                        Intent toProfile= new Intent(getApplicationContext(), ProfileService.class);
                        startActivity(toProfile);
                        overridePendingTransition(0,0);
                        return true;
                    }

                }
                return false;
            }
        });

        AcceptOffer= (Button) findViewById(R.id.AcceptOffer);
        DeclineOffer= (Button) findViewById(R.id.DeclineOffer);

        AcceptOffer.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
//                ModifyOfferStatus(1, ClientName, ClientPhone,    TimeStamp);

            }
        });
        DeclineOffer.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
//                ModifyOfferStatus(2, TimeStamp);

            }
        });

    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}